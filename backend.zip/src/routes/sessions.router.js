import { Router } from "express";
import passport from "passport";
import { generateToken } from "../utils/jwt.js";
import UserDTO from "../dtos/UserDTO.js";


const router = Router();

// POST /api/sessions/register
router.post("/register", (req, res, next) => {
  passport.authenticate("register", { session: false }, (err, user) => {
    if (err) {
      return res.status(500).send({
        status: "error",
        message: "Error interno del servidor"
      });
    }

    if (!user) {
      return res.status(400).send({
        status: "error",
        message: "No fue posible registrar el usuario"
      });
    }

    return res.status(201).send({
      status: "success",
      message: "Usuario registrado correctamente"
    });
  })(req, res, next);
});

// POST /api/sessions/login
router.post("/login", (req, res, next) => {
  passport.authenticate("login", { session: false }, (err, user) => {
    if (err) {
      return res.status(500).send({
        status: "error",
        message: "Error interno del servidor"
      });
    }

    if (!user) {
      return res.status(401).send({
        status: "error",
        message: "Credenciales incorrectas"
      });
    }

    const token = generateToken(user);

    return res
      .cookie("jwt", token, {
        httpOnly: true,
        sameSite: "lax"
      })
      .send({
        status: "success",
        message: "Login exitoso"
      });
  })(req, res, next);
});

// GET /api/sessions/current -> DTO
router.get("/current", (req, res, next) => {
  passport.authenticate("current", { session: false }, (err, user) => {
    if (err) {
      return res.status(500).send({
        status: "error",
        message: "Error interno del servidor"
      });
    }

    if (!user) {
      return res.status(401).send({
        status: "error",
        message: "No autorizado"
      });
    }

    const safeUser = new UserDTO(user);

    return res.send({
      status: "success",
      payload: safeUser
    });
  })(req, res, next);
});

// POST /api/sessions/logout
router.post("/logout", (req, res) => {
  res.clearCookie("jwt");
  return res.status(200).send({
    status: "success",
    message: "Logout exitoso"
  });
});

// POST /api/sessions/forgot-password
router.post("/forgot-password", async (req, res, next) => {
  try {
    const { email } = req.body;
    const previewUrl = await (await import("../services/sessions.service.js")).default.forgotPassword(email);

    return res.status(200).json({
      status: "success",
      message: "Si el email existe, se envió un enlace de recuperación",
      ...(previewUrl ? { previewUrl } : {}),
    });
  } catch (err) {
    next(err);
  }
});

// POST /api/sessions/reset-password
router.post("/reset-password", async (req, res, next) => {
  try {
    await (await import("../services/sessions.service.js")).default.resetPassword(req.body);
    return res.status(200).json({ status: "success", message: "Contraseña actualizada" });
  } catch (err) {
    next(err);
  }
});


export default router;
